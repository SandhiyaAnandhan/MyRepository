package com.example.springboot.controller;
import org.springframework.ui.Model;
import com.example.springboot.entity.Patients;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.springboot.service.PatientService;

@Controller
public class PatientController {
	
	private PatientService patientService;

	public PatientController(PatientService patientServive) {
		super();
		this.patientService = patientServive;
	}
	
	@GetMapping("/patients")
	public String listPatients(Model model) {
		model.addAttribute("patients", patientService.getAllPatients());
		return "patients";
		
	}

	@GetMapping("/patients/new")
	public String createPatientForm(Model model) {
		Patients patient = new Patients();
		model.addAttribute("patient", patient);                            //"patients"
		return "create_patient";
	}
	
	@PostMapping("/patients")
	public String savePatient(@ModelAttribute("patient") Patients patient ) {
		patientService.savePatient(patient);
		return "redirect:/patients";
	}
	
	@GetMapping("/patients/edit/{id}")
	public String editPatientForm(@PathVariable Long id, Model model) {
		model.addAttribute("patient",patientService.getPatientById(id));
		return "edit_patient";
	}
	
	@PostMapping("/patients/{id}")
	public String updatePatient(@PathVariable Long id, @ModelAttribute("patient") Patients patient, Model model) {
		//get pat by db by id
		Patients existingPatient = patientService.getPatientById(id);
		existingPatient.setId(id);
		existingPatient.setFirstName(patient.getFirstName());
		existingPatient.setLastName(patient.getLastName());
		existingPatient.setEmail(patient.getEmail());
		existingPatient.setAge(patient.getAge());
		existingPatient.setDoctor(patient.getDoctor());
		existingPatient.setPhoneno(patient.getPhoneno());
		existingPatient.setAddress(patient.getAddress());
		//save
		patientService.updatePatient(existingPatient);
		return "redirect:/patients";
		
	}
	
	@GetMapping("/patients/{id}")
	public String deletePatient(@PathVariable Long id) {
		patientService.deletePatientById(id);
		return "redirect:/patients";
	}
	
	@GetMapping("/about")
	public String about() {
		return "about";
	}
	
	@GetMapping("/doctors")
	public String doctors() {
		return "doctors";
	}
	
	@GetMapping("/service")
	public String services() {
		return "service";
	}
	
	@GetMapping("/contact")
	public String contactus() {
		return "contact";
	}

	@GetMapping("/equipments")
	public String Equipments() {
		return "equipments";
	}

	@GetMapping("/facilities")
	public String Facilities() {
		return "facilities";
	}

	

	
	
}
