package com.example.springboot.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.springboot.entity.Patients;
import com.example.springboot.repository.PatientRepository;
import com.example.springboot.service.PatientService;

@Service
public class PatientServiceImpl implements PatientService {
	
	private PatientRepository PatientRepository;
	
	

	public PatientServiceImpl(PatientRepository patientRepository) {
		super();
		this.PatientRepository = patientRepository;
	}



	@Override
	public List<Patients> getAllPatients() {
		return PatientRepository.findAll();
	}



	@Override
	public Patients savePatient(Patients patient) {
		return PatientRepository.save(patient);
	}



	@Override
	public Patients getPatientById(Long id) {
		return PatientRepository.findById(id).get();
	}



	@Override
	public Patients updatePatient(Patients patient) {
		return PatientRepository.save(patient);
	}



	@Override
	public void deletePatientById(Long id) {
		PatientRepository.deleteById(id);
		
	}

}
